"""Student diagnostics agent."""

