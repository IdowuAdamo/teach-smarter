"""Teaching strategy agent."""

