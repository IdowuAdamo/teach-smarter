"""Shared agent utilities."""

