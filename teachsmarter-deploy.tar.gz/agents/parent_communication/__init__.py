"""Parent communication agent."""

